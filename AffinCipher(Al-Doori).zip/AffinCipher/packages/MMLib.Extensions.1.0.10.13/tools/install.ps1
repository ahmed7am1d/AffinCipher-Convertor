param($installPath, $toolsPath, $package, $project)
    $DTE.ItemOperations.Navigate("https://mmlib.codeplex.com/documentation")